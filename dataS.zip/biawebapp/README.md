# example of dash making html

## <https://plotly.com/examples/>

-------------------

# Example of px export as html file

<https://plotly.com/python/embedding-plotly-graphs-in-HTML/#:~:text=Plotly%20graphs%20can%20be%20embedded>,Plotly%20graphs%20with%20the%20plotly

<https://plotly.com/python/interactive-html-export/>

------------------------

## Idase

<https://www.iea.org/data-and-statistics/data-sets>

-----------------------

## To use

- Conda
  - [cheatsheet](https://docs.conda.io/projects/conda/en/4.6.0/_downloads/52a95608c49671267e40c689e0bc00ca/conda-cheatsheet.pdf)
  - run script cmd`conda create --name biaweb python=3.10`
  - `conda activate biaweb`
  - `pip install -r requirement.txt`
  - Run the `main.py`, **being in same directory of main.py is required**
